/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fftchannelizer.demos;

import fftchannelizer.Complex;
import fftchannelizer.ComplexFloat;
import fftchannelizer.FFT;
import fftchannelizer.Grapher;
import fftchannelizer.PolyphaseFFT;
import fftchannelizer.RadixTwoFFT;
import fftchannelizer.SixStepFFT;
import fftchannelizer.signals.MonotoneSignal;
import fftchannelizer.signals.WidebandSignal;
import fftchannelizer.windows.DolphChebyshevWindow;
import fftchannelizer.windows.KaiserWindow;
import fftchannelizer.windows.Window;

/**
 *
 * @author aensor
 */
public class CoarseFineResponseDemo
{

    public static void main(String[] args)
    {
        int numCoarseChannels = 256;
        int numFineChannels = 256;
//        double blockTime = numCoarseChannels * numFineChannels * 1.0 / 5.0E8; // time for one FFT block of samples
        double blockTime = 1.0; // time for one FFT block of samples used if want to label channel offsets
        System.out.println("FFT block is " + blockTime + " seconds");
        int numChannels = numCoarseChannels * numFineChannels;
        int resolution = 12; // resolution of frequency response graph between adjacent channels
        double channelFreqSpacing = 1.0 / blockTime; // frequency spacing of adjacent channels
        int numCoarseTaps = 8; // number of taps for coarse stage of polyphase filter FFT
        int numFineTaps = 8; // number of taps for fine stage of polyphase filter FFT
        double toneFrequency = numChannels / (2 * blockTime);
        // generate a set of tones with different offsets from the tone frequency
        WidebandSignal[] signal = new WidebandSignal[resolution];
        for (int i = 0; i < resolution; i++)
        {
            double freqOffset = channelFreqSpacing * i / resolution;
            signal[i] = new MonotoneSignal(ComplexFloat.COMPLEX_TYPE, toneFrequency - freqOffset);
        }

//        // perform single stage FFT using decimation in time
//        FFT plainFFT = new RadixTwoFFT(numChannels);
//        Complex[][] plainChannels = new Complex[resolution][numChannels];
//        for (int i = 0; i < resolution; i++)
//        {
//            plainChannels[i] = plainFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels)); // FIX TIME INTERVAL ISSUE
//        }

        // create window for wideband signal
//        Window window = new BlackmanWindow(numChannels);
        Window window = new KaiserWindow(numChannels, 2.5);

        // perform single stage FFT with window applied to wideband
        FFT windowedFFT = new RadixTwoFFT(numChannels, window);
        Complex[][] windowedChannels = new Complex[resolution][numChannels];
        for (int i = 0; i < resolution; i++)
        {
            windowedChannels[i] = windowedFFT.transform(signal[i].getPureSignals(
                    0, blockTime, numChannels));
        }

        // perform polyphase FFT with additional windowing
        FFT[] polyphaseFFT = new FFT[resolution];
        Complex[][] polyphaseChannels = new Complex[resolution][numChannels];
        for (int i = 0; i < resolution; i++)
        {
            FFT[] coarseFFT = new FFT[numFineChannels];
            for (int j = 0; j < numFineChannels; j++)
            {
                Window polyphaseCoarseWindow = new KaiserWindow(numCoarseChannels * numCoarseTaps, 3);
//                Window polyphaseCoarseWindow = new DolphChebyshevWindow(numCoarseChannels * numTaps, 5);
                polyphaseCoarseWindow.setLargeWindow(j, numChannels * numCoarseTaps);
                coarseFFT[j] = new PolyphaseFFT(numCoarseChannels, numCoarseTaps, polyphaseCoarseWindow);
//                coarseFFT[j] = new RadixTwoFFT(numCoarseChannels, polyphaseCoarseWindow);
            }
            FFT[] fineFFT = new FFT[numCoarseChannels];
            for (int j = 0; j < numCoarseChannels; j++)
            {
                Window polyphaseFineWindow = new KaiserWindow(numFineChannels * numFineTaps, 3);
                polyphaseFineWindow.setLargeWindow(j, numChannels * numFineTaps);
                fineFFT[j] = new PolyphaseFFT(numFineChannels, numFineTaps, polyphaseFineWindow);
//                fineFFT[j] = new RadixTwoFFT(numFineChannels, polyphaseFineWindow);
            }
            polyphaseFFT[i] = new SixStepFFT(coarseFFT, fineFFT);
            // apply the earlier wideband signals to the coarse polyphase filter
            for (int tap = 0; tap < numCoarseTaps; tap++)
            {
                double tapStartTime = (tap + 1 - numCoarseTaps) * blockTime;
                Complex[] widebandBlock = signal[i].getPureSignals(tapStartTime,
                        tapStartTime + blockTime, numChannels);
                // only the last FFT tap block is kept, others only to set up polyphase filter
                polyphaseChannels[i] = coarseFFT[i].transform(widebandBlock);
            }
        }

        // combine all back together
        int totalChannels = resolution * numChannels;
//        Complex[] plainResponse = new Complex[totalChannels];
        Complex[] windowedResponse = new Complex[totalChannels];
        Complex[] polyphaseResponse = new Complex[totalChannels];
        for (int j = 0; j < totalChannels; j++)
        {
            int i = j % resolution;
            int channel = j / resolution;
//            plainResponse[j] = plainChannels[i][channel];
            windowedResponse[j] = windowedChannels[i][channel];
            polyphaseResponse[j] = polyphaseChannels[i][channel];
        }
//        Grapher grapher = new Grapher("Coarse+Fine Polyphase Frequency Response", "Hz", "dB");
        Grapher grapher = new Grapher("Coarse+Fine Polyphase Frequency Response", "Channel Offset", "dB");
//        grapher.addDataSeries(plainResponse, "Non-windowed", Grapher.Mode.DECIBEL,
//                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(windowedResponse, "Windowed", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(polyphaseResponse, "Polyphase", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.show();
    }
}
