/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fftchannelizer.demos;

import fftchannelizer.Complex;
import fftchannelizer.ComplexDouble;
import fftchannelizer.FFT;
import fftchannelizer.Grapher;
import fftchannelizer.RadixTwoFFT;
import fftchannelizer.signals.MonotoneSignal;
import fftchannelizer.signals.WidebandSignal;
import fftchannelizer.windows.FlattopWindow;
import fftchannelizer.windows.Window;

/**
 *
 * @author aensor
 */
public class FlattopWindowResponseDemo
{
    public static void main(String[] args)
    {
        int decimation = 4;
        double blockTime = 1.0; // time for one FFT block of samples
        int numChannels = 512;
        int resolution = 50; // resolution of frequency response graph between adjacent channels
        double channelFreqSpacing = 1.0 / blockTime; // frequency spacing of adjacent channels
        double toneFrequency = numChannels / (2 * blockTime);
        // generate a set of tones with different offsets from the tone frequency
        WidebandSignal[] signal = new WidebandSignal[resolution];
        for (int i = 0; i < resolution; i++)
        {
            double freqOffset = channelFreqSpacing * i / resolution;
            signal[i] = new MonotoneSignal(ComplexDouble.COMPLEX_TYPE, toneFrequency - freqOffset);
        }

        // perform single stage FFT using decimation in time
        FFT plainFFT = new RadixTwoFFT(numChannels);
        Complex[][] plainChannels = new Complex[resolution][numChannels];
        for (int i = 0; i < resolution; i++)
        {
            plainChannels[i] = plainFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels)); // FIX TIME INTERVAL ISSUE
        }

        // create window for wideband signal
        Window sr785Window = new FlattopWindow(numChannels, FlattopWindow.NAME.SR785);
        Window hft248dWindow = new FlattopWindow(numChannels, FlattopWindow.NAME.HFT70);
        Window fd3ftc1Window = new FlattopWindow(numChannels, FlattopWindow.NAME.FD3FTC1);
        Window fd4ftc1Window = new FlattopWindow(numChannels, FlattopWindow.NAME.FD4FTC1);
        Window fd5ftc1Window = new FlattopWindow(numChannels, FlattopWindow.NAME.FD5FTC1);
        Window ms4ftc1Window = new FlattopWindow(numChannels, FlattopWindow.NAME.MS4FTC1);
        Window ms5ftc1Window = new FlattopWindow(numChannels, FlattopWindow.NAME.MS5FTC1);

        // perform single stage FFT with window applied to wideband
        System.out.println("Starting single stage...");
        FFT sr785WindowedFFT = new RadixTwoFFT(numChannels, sr785Window);
        FFT hft248dWindowedFFT = new RadixTwoFFT(numChannels, hft248dWindow);
        FFT fd3ftc1WindowedFFT = new RadixTwoFFT(numChannels, fd3ftc1Window);
        FFT fd4ftc1WindowedFFT = new RadixTwoFFT(numChannels, fd4ftc1Window);
        FFT fd5ftc1WindowedFFT = new RadixTwoFFT(numChannels, fd5ftc1Window);
        FFT ms4ftc1WindowedFFT = new RadixTwoFFT(numChannels, ms4ftc1Window);
        FFT ms5ftc1WindowedFFT = new RadixTwoFFT(numChannels, ms5ftc1Window);
        Complex[][] sr785WindowedChannels = new Complex[resolution][numChannels];
        Complex[][] hft248dWindowedChannels = new Complex[resolution][numChannels];
        Complex[][] fd3ftc1WindowedChannels = new Complex[resolution][numChannels];
        Complex[][] fd4ftc1WindowedChannels = new Complex[resolution][numChannels];
        Complex[][] fd5ftc1WindowedChannels = new Complex[resolution][numChannels];
        Complex[][] ms4ftc1WindowedChannels = new Complex[resolution][numChannels];
        Complex[][] ms5ftc1WindowedChannels = new Complex[resolution][numChannels];
        for (int i = 0; i < resolution; i++)
        {
            sr785WindowedChannels[i] = sr785WindowedFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels));
            hft248dWindowedChannels[i] = hft248dWindowedFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels));
            fd3ftc1WindowedChannels[i] = fd3ftc1WindowedFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels));
            fd4ftc1WindowedChannels[i] = fd4ftc1WindowedFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels));
            fd5ftc1WindowedChannels[i] = fd5ftc1WindowedFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels));
            ms4ftc1WindowedChannels[i] = ms4ftc1WindowedFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels));
            ms5ftc1WindowedChannels[i] = ms5ftc1WindowedFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels));
        }

        // combine all back together
        System.out.println("Starting combine stage...");
        int totalChannels = resolution * numChannels / decimation;
        Complex[] plainResponse = new Complex[totalChannels];
        Complex[] sr785WindowedResponse = new Complex[totalChannels];
        Complex[] hft248dWindowedResponse = new Complex[totalChannels];
        Complex[] fd3ftc1WindowedResponse = new Complex[totalChannels];
        Complex[] fd4ftc1WindowedResponse = new Complex[totalChannels];
        Complex[] fd5ftc1WindowedResponse = new Complex[totalChannels];
        Complex[] ms4ftc1WindowedResponse = new Complex[totalChannels];
        Complex[] ms5ftc1WindowedResponse = new Complex[totalChannels];
        for (int j = 0; j < totalChannels; j++)
        {
            int i = (j*decimation) % resolution;
            int channel = (j*decimation) / resolution;
            plainResponse[j] = plainChannels[i][channel];
            sr785WindowedResponse[j] = sr785WindowedChannels[i][channel];
            hft248dWindowedResponse[j] = hft248dWindowedChannels[i][channel];
            fd3ftc1WindowedResponse[j] = fd3ftc1WindowedChannels[i][channel];
            fd4ftc1WindowedResponse[j] = fd4ftc1WindowedChannels[i][channel];
            fd5ftc1WindowedResponse[j] = fd5ftc1WindowedChannels[i][channel];
            ms4ftc1WindowedResponse[j] = ms4ftc1WindowedChannels[i][channel];
            ms5ftc1WindowedResponse[j] = ms5ftc1WindowedChannels[i][channel];
        }
        numChannels /= decimation;
        System.out.println("Starting graphing stage...");
        Grapher grapher = new Grapher("Flat-Top Window Frequency Response", "Channel Offset", "dB");
//        grapher.addDataSeries(plainResponse, "Non-windowed", Grapher.Mode.DECIBEL,
//                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(sr785WindowedResponse, "SR785 Window", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(hft248dWindowedResponse, "HFT248D Window", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(fd3ftc1WindowedResponse, "FD3FTC1 Window", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(fd4ftc1WindowedResponse, "FD4FTC1 Window", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(fd5ftc1WindowedResponse, "FD5FTC1 Window", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(ms4ftc1WindowedResponse, "MS4FTC1 Window", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(ms5ftc1WindowedResponse, "MS5FTC1 Window", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.show();
        System.out.println("Completed");
    }
    
}
