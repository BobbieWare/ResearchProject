/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fftchannelizer.demos;

import fftchannelizer.Complex;
import fftchannelizer.ComplexFloat;
import fftchannelizer.FFT;
import fftchannelizer.Grapher;
import fftchannelizer.PolyphaseFFT;
import fftchannelizer.RadixTwoFFT;
import fftchannelizer.signals.MonotoneSignal;
import fftchannelizer.signals.WidebandSignal;
import fftchannelizer.windows.DolphChebyshevWindow;
import fftchannelizer.windows.FlattopWindow;
import fftchannelizer.windows.KaiserWindow;
import fftchannelizer.windows.Window;

/**
 *
 * @author aensor
 */
public class OversamplingFrequencyResponseDemo
{
    public static void main(String[] args)
    {
        int decimation = 4;
        double blockTime = 1.0; // time for one FFT block of samples
        int numChannels = 512;
        int resolution = 20; // resolution of frequency response graph between adjacent channels
        double channelFreqSpacing = 1.0 / blockTime; // frequency spacing of adjacent channels
        int numTaps = 12; // number of taps for polyphase filter FFT
        double toneFrequency = numChannels / (2 * blockTime);
        // generate a set of tones with different offsets from the tone frequency
        WidebandSignal[] signal = new WidebandSignal[resolution];
        for (int i = 0; i < resolution; i++)
        {
            double freqOffset = channelFreqSpacing * i / resolution;
            signal[i] = new MonotoneSignal(ComplexFloat.COMPLEX_TYPE, toneFrequency - freqOffset);
        }

        // perform single stage FFT using decimation in time
        FFT plainFFT = new RadixTwoFFT(numChannels);
        Complex[][] plainChannels = new Complex[resolution][numChannels];
        for (int i = 0; i < resolution; i++)
        {
            plainChannels[i] = plainFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels)); // FIX TIME INTERVAL ISSUE
        }

        // create window for wideband signal
        Window flattopWindow = new FlattopWindow(numChannels, FlattopWindow.NAME.SR785);
        Window kaiserWindow = new KaiserWindow(numChannels, 2.6);
        Window dcWindow = new DolphChebyshevWindow(numChannels, 3);

        // perform single stage FFT with window applied to wideband
        System.out.println("Starting single stage...");
        FFT flattopWindowedFFT = new RadixTwoFFT(numChannels, flattopWindow);
        FFT kaiserWindowedFFT = new RadixTwoFFT(numChannels, kaiserWindow);
        FFT dcWindowedFFT = new RadixTwoFFT(numChannels, dcWindow);
        Complex[][] flattopWindowedChannels = new Complex[resolution][numChannels];
        Complex[][] kaiserWindowedChannels = new Complex[resolution][numChannels];
        Complex[][] dcWindowedChannels = new Complex[resolution][numChannels];
        for (int i = 0; i < resolution; i++)
        {
            flattopWindowedChannels[i] = flattopWindowedFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels));
            kaiserWindowedChannels[i] = kaiserWindowedFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels));
            dcWindowedChannels[i] = dcWindowedFFT.transform(signal[i].getPureSignals(0, blockTime, numChannels));
        }

        // perform polyphase FFT with additional windowing
        System.out.println("Starting polyphase stage...");
        FFT[] polyphaseFFT = new FFT[resolution];
        Complex[][] polyphaseChannels = new Complex[resolution][numChannels];
        Window polyphaseWindow = new DolphChebyshevWindow(numChannels * numTaps, 5);
        for (int i = 0; i < resolution; i++)
        {
            polyphaseFFT[i] = new PolyphaseFFT(numChannels, numTaps, polyphaseWindow);
            // apply the earlier wideband signals to the polyphase filter
            for (int tap = 0; tap < numTaps; tap++)
            {
                double tapStartTime = (tap + 1 - numTaps) * blockTime;
                Complex[] widebandBlock = signal[i].getPureSignals(tapStartTime,
                        tapStartTime + blockTime, numChannels);
                // only the last FFT tap block is kept, others only to set up polyphase filter
                polyphaseChannels[i] = polyphaseFFT[i].transform(widebandBlock);
            }
        }

        // combine all back together
        System.out.println("Starting combine stage...");
        int totalChannels = resolution * numChannels / decimation;
        Complex[] plainResponse = new Complex[totalChannels];
        Complex[] flattopWindowedResponse = new Complex[totalChannels];
        Complex[] kaiserWindowedResponse = new Complex[totalChannels];
        Complex[] dcWindowedResponse = new Complex[totalChannels];
        Complex[] polyphaseResponse = new Complex[totalChannels];
        for (int j = 0; j < totalChannels; j++)
        {
            int i = (j*decimation) % resolution;
            int channel = (j*decimation) / resolution;
            plainResponse[j] = plainChannels[i][channel];
            flattopWindowedResponse[j] = flattopWindowedChannels[i][channel];
            kaiserWindowedResponse[j] = kaiserWindowedChannels[i][channel];
            dcWindowedResponse[j] = dcWindowedChannels[i][channel];
            polyphaseResponse[j] = polyphaseChannels[i][channel];
        }
        numChannels /= decimation;
        System.out.println("Starting graphing stage...");
        Grapher grapher = new Grapher("Frequency Response", "Channel Offset", "dB");
        grapher.addDataSeries(plainResponse, "Non-windowed", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(flattopWindowedResponse, "Flattop Windowed", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(kaiserWindowedResponse, "Kaiser Windowed", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(dcWindowedResponse, "Dolph-Chebyshev Windowed", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.addDataSeries(polyphaseResponse, "DolphChebyshev Polyphase", Grapher.Mode.DECIBEL,
                channelFreqSpacing / resolution, 1, -numChannels/2);
        grapher.show();
        System.out.println("Completed");
    }
    
}
