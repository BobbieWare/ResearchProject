/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fftchannelizer;

import fftchannelizer.signals.PolytoneSignal;
import fftchannelizer.signals.WidebandSignal;
import fftchannelizer.windows.Window;
import java.util.Arrays;

/**
 *
 * @author aensor
 */
public class CascadedPolyphaseFFT extends FFT 
{

    private int numCoarseChannels, numFineChannels;
    private FFT[] coarseFFT; // either a single coarse PolyphaseFFT or one for each fine channelization
    private FFT[] fineFFT; // either a single fine PolyphaseFFT or one for each coarse channelization
    private int numRemainingFineChannels; // number of fine channels not culled, used to calculate oversampling factor

    public CascadedPolyphaseFFT(int numCoarseChannels, int numFineChannels,
            int numCoarseTaps, int numFineTaps, int numRemainingFineChannels)
    {
        this(numCoarseChannels, numFineChannels, numCoarseTaps, numFineTaps, numRemainingFineChannels, null, null);
    }

    public CascadedPolyphaseFFT(int numCoarseChannels, int numFineChannels,
            int numCoarseTaps, int numFineTaps, int numRemainingFineChannels,
            Window coarseWindow, Window fineWindow)
    {
        this(new FFT[]{new PolyphaseFFT(numCoarseChannels, numCoarseTaps, coarseWindow)},
                new FFT[]{new PolyphaseFFT(numFineChannels, numFineTaps, fineWindow)});
        this.numRemainingFineChannels = numRemainingFineChannels;
    }
    
    public CascadedPolyphaseFFT(FFT[] coarseFFT, FFT[] fineFFT)
    {
        super(coarseFFT[0].getNumChannels() * fineFFT[0].getNumChannels(),
                coarseFFT[0].getWindow()); // use coarse FFT window as indicative window
        this.numCoarseChannels = coarseFFT[0].getNumChannels();
        this.numFineChannels = fineFFT[0].getNumChannels();
        this.coarseFFT = coarseFFT;
        this.fineFFT = fineFFT;
        for (int i=0; i<coarseFFT.length; i++)
        {
            if (coarseFFT[i].getNumChannels() != numCoarseChannels)
                throw new IllegalArgumentException("Coarse FFT "+ i+" has different number of channels");
        }
        for (int i=0; i<fineFFT.length; i++)
        {
            if (fineFFT[i].getNumChannels() != numFineChannels)
                throw new IllegalArgumentException("Fine FFT "+ i+" has different number of channels");
        }
    }

    // performs a six-step FFT presuming original.length divisible by numCoarseChannels
    public Complex[] transform(Complex[] original)
    {
        if (original.length != numCoarseChannels * numFineChannels)
        {
            throw new IllegalArgumentException("Invalid FFT size: " + original.length);
        }
        double oversamplingFactor = 1.0*numCoarseChannels/numRemainingFineChannels;
        // perform coarse channelization
        Complex[][] matrixOriginal = Complex.makeMatrix(original, numFineChannels);
        Complex[][] coarseChannels = Complex.transpose(transform(
                Complex.transpose(matrixOriginal), coarseFFT));
        // perform twiddle factors on all but first channels
        for (int i = 0; i < numCoarseChannels; i++)
        {
            for (int j = 0; j < numFineChannels; j++)
            {
                Complex twiddleFactor = (i * j != 0 ? original[0].getRootOfUnity(
                        1.0 * original.length / (i * j)) : original[0].getUnit());
                coarseChannels[i][j] = coarseChannels[i][j].multiplyInPlace(twiddleFactor);
            }
        }
        // perform fine channelization
        Complex[][] fineChannels = transform(coarseChannels, fineFFT);
        // reassemble into single array
        Complex[] sixStepChannels = Complex.flatten(Complex.transpose(fineChannels));
        return sixStepChannels;
    }

    // performs a six-step FFT presuming original.length divisible by numCoarseChannels and zoom
    // note that the zoom is not currently set up for changing FFT
    public Complex[] sixStepZoom(Complex[] original, int zoom)
    {
        if (original.length != numCoarseChannels * numFineChannels * zoom)
        {
            throw new IllegalArgumentException("Invalid FFT size: " + original.length);
        }
        // perform coarse channelization for each zoom
        int blockSize = original.length / zoom;
        Complex[][] coarseZoomBlocks = new Complex[numCoarseChannels][numFineChannels * zoom];
        for (int z = 0; z < zoom; z++)
        {
            Complex[][] matrixOriginal = Complex.makeMatrix(
                    Arrays.copyOfRange(original, z * blockSize, (z + 1) * blockSize), numFineChannels);
            Complex[][] coarseChannels = Complex.transpose(
                    transform(Complex.transpose(matrixOriginal), coarseFFT));
            // perform twiddle factors on all but first channels
            for (int i = 0; i < numCoarseChannels; i++)
            {
                for (int j = 0; j < numFineChannels; j++)
                {
                    Complex twiddleFactor = (i * j != 0
                            ? original[0].getRootOfUnity(
                            1.0 * blockSize / (i * j))
                            : original[0].getUnit()); // check mathematically this is correct
                    coarseChannels[i][j] = coarseChannels[i][j].multiplyInPlace(twiddleFactor);
                    coarseZoomBlocks[i][z * numFineChannels + j] = coarseChannels[i][j];
                }
            }
        }

        // perform fine channelization
        FFT[] fineZoomFFT = new FFT[]{new RadixTwoFFT(numFineChannels * zoom)};
        Complex[][] fineChannels = transform(coarseZoomBlocks, fineZoomFFT);
        // now deblock the fine channels to give correct ordering
        Complex[] sixStepChannels = new Complex[original.length];
        for (int i = 0; i < original.length; i++)
        {
            int zoomNum = i % zoom;
            int coarseChannel = (i / zoom) % numCoarseChannels;
            int zoomedChannel = ((i / zoom) / numCoarseChannels) * zoom;
            sixStepChannels[i] = fineChannels[coarseChannel][zoomedChannel + zoomNum];
        }
        return sixStepChannels;
    }

    // transform FFT row by row
    public Complex[][] transform(Complex[][] original, FFT[] fft)
    {
        Complex[][] channels = new Complex[original.length][];
        for (int i = 0; i < original.length; i++)
        {
            channels[i] = fft[i % fft.length].transform(original[i]);
        }
        return channels;
    }

    public static void main(String[] args)
    {
        // generate some data using powers of two
        int numCoarseChannels = 64;
        int numFineChannels = 16;
        int zoom = 1;
        int totalNumChannels = numCoarseChannels * numFineChannels * zoom;
        WidebandSignal signal = new PolytoneSignal(ComplexDouble.COMPLEX_TYPE,
                new double[]{
                    0, 2, 4, 5, 6, 8
                }, new double[]
                {
                    0.1, 0.4, 1.6, 5, 20, 40
                }, null);
        Complex[] wideband = signal.getPureSignals(0, 1, totalNumChannels);

        System.out.println("Wideband = " + Complex.toString(wideband));
        // perform single stage FFT
        FFT fft = new RadixTwoFFT(totalNumChannels);
        Complex[] channels = fft.transform(wideband);
        System.out.println("Channels =    " + Complex.toString(channels));
        // perform six-step FFT
        SixStepFFT sixStepFFT = new SixStepFFT(numCoarseChannels, numFineChannels);
//        Complex[] sixStepChannels = sixStepFFT.sixStepZoom(wideband, zoom);
        Complex[] sixStepChannels = sixStepFFT.transform(wideband);
        System.out.println("Coarse+Fine = " + Complex.toString(sixStepChannels));

        // compare fft with six-step
        double sumDifferences = 0;
        for (int i = 0; i < wideband.length; i++)
        {
            sumDifferences += channels[i].subtract(sixStepChannels[i]).modulus();
        }
        System.out.println("Difference is " + sumDifferences);
    }
}
