/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fftchannelizer;

import fftchannelizer.signals.PolytoneSignal;
import fftchannelizer.signals.WidebandSignal;
import fftchannelizer.windows.KaiserWindow;
import fftchannelizer.windows.Window;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.axis.TickUnit;
import org.jfree.chart.axis.TickUnitSource;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 *
 * @author aensor
 */
public class Grapher implements TickUnitSource
{

    public enum Mode
    {

        MODULUS, REAL, IMAGINARY, DECIBEL
    }
    private String title, xLabel, yLabel;
    private XYSeriesCollection dataset;

    public Grapher(String title, String xLabel, String yLabel)
    {
        this.title = title;
        this.xLabel = xLabel;
        this.yLabel = yLabel;
        dataset = new XYSeriesCollection();
    }

    public void addDataSeries(Complex[] data, String name, Mode mode)
    {
        addDataSeries(data, name, mode, 1.0, 1.0);
    }

    public void addDataSeries(Complex[] data, String name, Mode mode, double xScale, double yScale)
    {
        addDataSeries(data, name, mode, xScale, yScale, 0.0);
    }
    public void addDataSeries(Complex[] data, String name, Mode mode, double xScale, double yScale, double xOffset)
    {
        XYSeries dataSeries = new XYSeries(name);
        switch (mode)
        {
            case MODULUS:
                for (int i = 0; i < data.length; i++)
                {
                    dataSeries.add(i * xScale + xOffset, data[i].modulus() * yScale);
                }
                break;
            case REAL:
                for (int i = 0; i < data.length; i++)
                {
                    dataSeries.add(i * xScale + xOffset, data[i].getReal() * yScale);
                }
                break;
            case IMAGINARY:
                for (int i = 0; i < data.length; i++)
                {
                    dataSeries.add(i * xScale + xOffset, data[i].getImaginary() * yScale);
                }
                break;
            case DECIBEL:
                // find max value in data
                double max = data[0].modulus();
                for (int i = 1; i < data.length; i++)
                {
                    double y = data[i].modulus();
                    if (y > max)
                    {
                        max = y;
                    }
                }
                for (int i = 0; i < data.length; i++)
                {
                    double y = data[i].modulus();
                    double db = 20 * Math.log10(y / max);
                    if (!Double.isInfinite(db) && !Double.isNaN(db))
                    {
                        dataSeries.add(i * xScale + xOffset, db * yScale);
                    }
                }
                break;
        }

        dataset.addSeries(dataSeries);
    }

    public void show()
    {
        JFreeChart chart = ChartFactory.createXYLineChart(title, xLabel, yLabel, dataset);
        XYPlot plot = chart.getXYPlot();
        plot.setDomainCrosshairVisible(true);
        plot.setRangeCrosshairVisible(true);
        plot.getDomainAxis().setStandardTickUnits(this);
        double maxDomainValue = dataset.getDomainUpperBound(false);
        plot.getDomainAxis().setRange(0, Math.round(Math.pow(2.0, Math.ceil(Math.log(maxDomainValue) / Math.log(2)))));
        ChartFrame frame = new ChartFrame("JChart", chart);
        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public TickUnit getLargerTickUnit(TickUnit unit)
    {
        double size = unit.getSize();
        double powerOfTwo = Math.round(Math.pow(2.0, Math.ceil(Math.log(size) / Math.log(2))));
        return new NumberTickUnit(powerOfTwo);
    }

    @Override
    public TickUnit getCeilingTickUnit(TickUnit unit)
    {
        double size = unit.getSize();
        double powerOfTwo = Math.round(Math.pow(2.0, Math.ceil(Math.log(size) / Math.log(2))));
        return new NumberTickUnit(powerOfTwo);
    }

    @Override
    public TickUnit getCeilingTickUnit(double size)
    {
        double powerOfTwo = Math.round(Math.pow(2.0, Math.ceil(Math.log(size) / Math.log(2))));
        return new NumberTickUnit(powerOfTwo);
    }

    public static void main(String[] args)
    {
        int numChannels = 512;
        FFT fft = new RadixTwoFFT(numChannels);
        WidebandSignal signal = new PolytoneSignal(ComplexDouble.COMPLEX_TYPE,
                new double[]
                {
                    numChannels / 4-0.5, numChannels / 3
                }, new double[]
                {
                    1, 1
                }, null);
        Complex[] wideband = signal.getPureSignals(0, 1, numChannels);

        // perform single stage FFT using decimation in time
        Complex[] plainChannels = fft.transform(wideband);
        // perform single stage FFT with window
//        Window window = Window.createDolphChebyshev(numChannels, 5);
        Window window = new KaiserWindow(numChannels, 3);
//        Window window = Window.createBartlett(numChannels);
        window.applyWindowInPlace(wideband);
        Complex[] windowedChannels = fft.transform(wideband);

        // compare ffts
        double sumDifferences = 0;
        for (int i = 0; i < wideband.length; i++)
        {
            sumDifferences += plainChannels[i].subtract(windowedChannels[i]).modulus();
        }
        System.out.println("Difference is " + sumDifferences);

        Grapher grapher = new Grapher("FFT", "Channel", "dB");
//        grapher.addDataSeries(wideband, "wideband", Grapher.Mode.REAL);
        grapher.addDataSeries(plainChannels, "Non-windowed", Grapher.Mode.DECIBEL);
        grapher.addDataSeries(windowedChannels, "Windowed", Grapher.Mode.DECIBEL);
        grapher.show();
    }
}
