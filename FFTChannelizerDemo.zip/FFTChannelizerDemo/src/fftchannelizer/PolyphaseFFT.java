/*
 * Perform polyphase filter FFT, also called window pre-sum FFT or windowed overlap-add (WOLA)
 */
package fftchannelizer;

import fftchannelizer.signals.MonotoneSignal;
import fftchannelizer.signals.WidebandSignal;
import fftchannelizer.windows.CombinedWindow;
import fftchannelizer.windows.SincWindow;
import fftchannelizer.windows.Window;

/**
 *
 * @author aensor
 */
public class PolyphaseFFT extends FFT
{

    private int numTaps;
    private FFT fft;
    private Complex[] allTapChannels;
    private Window sincWindow;

    public PolyphaseFFT(int numChannels, int numTaps)
    {
        this(numChannels, numTaps, null);
    }

    // constructor which includes an optional window to combine with the polyphase sinc window
    // note the sinc window adopts the offset of the optional window
    public PolyphaseFFT(int numChannels, int numTaps, Window window)
    {
        super(numChannels, null);
        if (window!=null && window.getSize() != numChannels*numTaps)
            throw new IllegalArgumentException("Polyphase FFT must use window across all taps");
        this.numChannels = numChannels;
        this.numTaps = numTaps;
        this.fft = new RadixTwoFFT(numChannels, null); // actual FFT uses no windowing
        allTapChannels = new Complex[numChannels * numTaps];
        this.sincWindow = new SincWindow(numChannels * numTaps, numTaps / 2.0);
        if (window != null)
        {
            this.sincWindow = new CombinedWindow(sincWindow, window);
            this.sincWindow.setLargeWindow(window.getLargeWindowOffset(), window.getLargeWindowWidth());
        }
    }

    // perform a polyphase filter FFT
    // Note that the polyphase filter FFT must be applied at least numTaps time on time series
    // data to popular the earlier taps
    public Complex[] transform(Complex[] original)
    {
        if (original.length != numChannels)
        {
            throw new IllegalArgumentException("Invalid FFT size: " + original.length);
        }
        // shift out the oldest tap block and shift in the newest input block
        for (int j = 0; j < (numChannels * (numTaps - 1)); j++)
        {
            allTapChannels[j] = allTapChannels[j + numChannels];
        }
        // copy the input into the final tap block
        for (int i = 0; i < numChannels; i++)
        {
            allTapChannels[numChannels * (numTaps - 1) + i] = original[i].getCopy();
        }
        // apply sinc window and sum across all tap blocks
        Complex[] summedChannels = new Complex[numChannels];
        for (int i = 0; i < numChannels; i++)
        {
            if (allTapChannels[i] != null)
            {
                summedChannels[i] = allTapChannels[i].getCopy();
                summedChannels[i].multiplyInPlace(sincWindow.getEntry(i));
            } else
            {
                summedChannels[i] = original[i].getNew(0, 0);
            }
            for (int tap = 1; tap < numTaps; tap++)
            {
                int allChannelIndex = numChannels * tap + i;
                if (allTapChannels[allChannelIndex] != null)
                {
                    Complex term = allTapChannels[allChannelIndex].multiply(
                            sincWindow.getEntry(allChannelIndex));
                    summedChannels[i].addInPlace(term);
                }
            }
        }
        Complex[] channels = fft.transform(summedChannels);
        return channels;
    }

    public static void main(String[] args)
    {
        int numChannels = 512;
        int numTaps = 8;
        double frequencyOffset = 0.5;
        double toneFrequency = numChannels / 3 - frequencyOffset;
        // generate a set of tones with different offsets from the tone frequency
        WidebandSignal signal = new MonotoneSignal(ComplexDouble.COMPLEX_TYPE,
                toneFrequency);
        PolyphaseFFT polyphaseFFT = new PolyphaseFFT(numChannels, numTaps);
        // populate prior tap blocks presuming each tap block corresponds to 1s
        for (int time = 0; time < 7; time++)
        {
            polyphaseFFT.transform(signal.getPureSignals(time, time+1, numChannels));
            System.out.println("time = "+time);
        }
        Complex[] wideband = signal.getPureSignals(7, 8, numChannels);
        Complex[] polyphaseChannels = polyphaseFFT.transform(wideband);
        // compare to plain FFT
        FFT fft = new RadixTwoFFT(numChannels);
        Complex[] ditChannels = fft.transform(wideband);
        // compare ffts
        double sumDifferences = 0;
        for (int i = 0; i < numChannels; i++)
        {
            sumDifferences += ditChannels[i].subtract(polyphaseChannels[i]).modulus();
        }
        System.out.println("Difference is " + sumDifferences);
        // graph results
        Grapher grapher = new Grapher("Frequency Response", "Channel", "dB");
        grapher.addDataSeries(ditChannels, "Plain FFT", Grapher.Mode.DECIBEL);
        grapher.addDataSeries(polyphaseChannels, "Polyphase", Grapher.Mode.DECIBEL);
        grapher.show();
    }
}
