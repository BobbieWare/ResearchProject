/*
 * Class that generates a wideband signal with a single tone of the specified
 * frequency and amplitude 1
 */
package fftchannelizer.signals;

import fftchannelizer.Complex;
import fftchannelizer.ComplexDouble;
import fftchannelizer.FFT;
import fftchannelizer.Grapher;
import fftchannelizer.RadixTwoFFT;
import fftchannelizer.signals.WidebandSignal;

/**
 *
 * @author aensor
 */
public class MonotoneSignal extends WidebandSignal
{

    private double omega; // angular frequency of tone
    private double initialPhase;

    public MonotoneSignal(Complex type, double toneFreq)
    {
        this(type, toneFreq, 0);
    }
    
    public MonotoneSignal(Complex type, double toneFreq, double initialPhase)
    {
        super(type);
        this.omega = Math.PI * 2.0 * toneFreq;
        this.initialPhase = initialPhase;
    }

    // returns a signal sample at the specified time with no additional noise
    public Complex getPureSignal(double time)
    {
        double angle = omega * time + initialPhase;
        return type.getNew(Math.cos(angle), Math.sin(angle));
    }
    
    public static void main(String[] args)
    {
        double time = 2.0;
        int numChannels = 64;
        double toneFrequency = 4.0/time;
        double toneFrequency2 = 4.0/time-0.05;
        double toneFrequency3 = 4.0/time-0.10;
        WidebandSignal signal = new MonotoneSignal(ComplexDouble.COMPLEX_TYPE, toneFrequency);
        WidebandSignal signal2 = new MonotoneSignal(ComplexDouble.COMPLEX_TYPE, toneFrequency2);
        WidebandSignal signal3 = new MonotoneSignal(ComplexDouble.COMPLEX_TYPE, toneFrequency3);
        Complex[] samples = signal.getPureSignals(0, time, numChannels);
        Complex[] samples2 = signal2.getPureSignals(0, time, numChannels);
        Complex[] samples3 = signal3.getPureSignals(0, time, numChannels);
        FFT fft = new RadixTwoFFT(numChannels);
        Complex[] channels = fft.transform(samples);
        Complex[] channels2 = fft.transform(samples2);
        Complex[] channels3 = fft.transform(samples3);
//        for (int i=0; i<samples.length; i++)
//        {
//            System.out.println("Channel " + i + ":" + samples[i]);
//        }
        Grapher grapher = new Grapher("Monotone Signal", "Time", "Strength");
        grapher.addDataSeries(channels, "4Hz", Grapher.Mode.REAL);
        grapher.addDataSeries(channels2, "3.9Hz", Grapher.Mode.REAL);
        grapher.addDataSeries(channels3, "3.8Hz", Grapher.Mode.REAL);
        grapher.show();
    }
}
