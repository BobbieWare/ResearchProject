/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fftchannelizer.signals;

import fftchannelizer.Complex;
import java.util.Random;

/**
 *
 * @author aensor
 */
public abstract class WidebandSignal
{
    protected Complex type; // type of complex signal generated
    
    public WidebandSignal(Complex type)
    {
        this.type = type;
    }
    
    public Complex getType()
    {
        return type;
    }
        
    // returns a new signal sample at the specified time with no additional noise
    public abstract Complex getPureSignal(double time);
    
    // returns an array of new signal samples from startTime (incl) to endTime (excl)
    public Complex[] getPureSignals(double startTime, double endTime, int numSamples)
    {
        Complex[] signal = new Complex[numSamples];
        for (int i=0; i<numSamples; i++)
        {
            double frac = 1.0*i/numSamples;
            double time = (1-frac)*startTime+frac*endTime;
//            double time = ((numSamples-i)*startTime+i*endTime)/numSamples;
            signal[i] = getPureSignal(time);
        }
        return signal;
    }
}
