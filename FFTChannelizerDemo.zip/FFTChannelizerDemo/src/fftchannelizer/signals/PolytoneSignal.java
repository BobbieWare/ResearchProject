/*
 * Class that generates a wideband signal with multiple tones of the specified
 * frequencies
 */
package fftchannelizer.signals;

import fftchannelizer.Complex;
import fftchannelizer.signals.WidebandSignal;

/**
 *
 * @author aensor
 */
public class PolytoneSignal extends WidebandSignal
{

    private double[] omega; // angular frequencies of tones
    private double[] toneAmplitude;
    private double[] initialPhase;

    public PolytoneSignal(Complex type, double[] toneFreq, double[] toneAmplitude, double[] initialPhase)
    {
        super(type);
        if (toneAmplitude == null)
        {
            toneAmplitude = new double[toneFreq.length];
            for (int i=0; i<toneFreq.length; i++)
            {
                toneAmplitude[i] = 1.0;
            }
        }
        if (initialPhase == null)
        {
            initialPhase = new double[toneFreq.length];
        }
        if (toneFreq.length != toneAmplitude.length || toneFreq.length != initialPhase.length)
        {
            throw new IllegalArgumentException("Inconsistent number of tones");
        }
        this.omega = new double[toneAmplitude.length];
        for (int i = 0; i < toneAmplitude.length; i++)
        {
            this.omega[i] = Math.PI * 2.0 * toneFreq[i];
        }
        this.toneAmplitude = toneAmplitude;
        this.initialPhase = initialPhase;
    }

    // returns a signal sample at the specified time with no additional noise
    public Complex getPureSignal(double time)
    {
        Complex signal = type.getNew(0, 0);
        for (int f = 0; f < omega.length; f++)
        {
            double angle = omega[f] * time + initialPhase[f];
            signal.addInPlace(type.getNew(
                    toneAmplitude[f] * Math.cos(angle), toneAmplitude[f] * Math.sin(angle)));
        }
        return signal;
    }
}
